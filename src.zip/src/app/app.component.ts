import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface College {
  name: string;
  type: string;
  location: string;
  established: number;
  students: {
    fullTime: number;
    partTime: number;
  };
  image: string;
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})

  
export class AppComponent implements OnInit {
  title = 'college-exam';

  college: College = {
    name: '',
    type: '',
    established: 0,
    students: {
      fullTime: 0,
      partTime: 0
    },
    image: '',
    location: ''
  };

  imageUrl: string;

  constructor(private http: HttpClient) {
    this.imageUrl = 'http://tetervak.dev.fast.sheridanc.on.ca/exams/angular/images/';
  }

  ngOnInit(): void {
    const dataUrl = 'http://tetervak.dev.fast.sheridanc.on.ca/exams/angular/data/sheridan_college.json';

    this.http.get<College>(dataUrl).subscribe(data => {
      this.college = data;
      this.college.image = this.imageUrl + this.college.image;
    });
  }
}
