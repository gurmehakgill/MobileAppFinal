import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

interface College {
  name: string;
  location: string;
  founded: number;
  ranking: number;
  imageUrl: string;
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'college-exam';

  college: College = {
    name: '',
    location: '',
    founded: 0,
    ranking: 0,
    imageUrl: 'http://tetervak.dev.fast.sheridanc.on.ca/exams/angular/images/sheridan_davis.jpg'
  };

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get<College>('http://tetervak.dev.fast.sheridanc.on.ca/exams/angular/data/sheridan_college.json').subscribe(data => {
      this.college = data;
    });
  }
}
